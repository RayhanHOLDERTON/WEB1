<?php

namespace Config;

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Artikel');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(false);

// --- ROUTE AUTENTIKASI (CI4 Session) ---
$routes->get('login', 'User::login');
$routes->post('login', 'User::login');
$routes->get('logout', 'User::logout');

// --- ROUTE PUBLIK ---
$routes->get('/', 'Artikel::index');
$routes->get('artikel', 'Artikel::index');
$routes->get('artikel/(:any)', 'Artikel::view/$1');
$routes->get('about', 'Page::about');
$routes->get('contact', 'Page::contact');

// --- ROUTE ADMIN INTERFACES ---
$routes->group('admin', ['filter' => 'authFilter'], function ($routes) {
    $routes->get('artikel', 'Artikel::admin_index');
    $routes->match(['get', 'post'], 'artikel/add', 'Artikel::add');
    $routes->match(['get', 'post'], 'artikel/edit/(:num)', 'Artikel::edit/$1');
    $routes->get('artikel/delete/(:num)', 'Artikel::delete/$1');

    $routes->get('ajax', 'AjaxController::index');
    $routes->get('ajax/data', 'AjaxController::getData');
    $routes->post('ajax/store', 'AjaxController::store');
    $routes->post('ajax/update/(:num)', 'AjaxController::update/$1');
    $routes->get('ajax/delete/(:num)', 'AjaxController::destroy/$1');
    $routes->get('ajax/get/(:num)', 'AjaxController::getById/$1');
});

// --- ROUTE REST API (Praktikum 10) ---
// GET boleh tanpa token, POST/PUT/DELETE wajib token (Praktikum 14)
$routes->get('post', 'Post::index');
$routes->get('post/(:num)', 'Post::show/$1');
$routes->post('post', 'Post::create', ['filter' => 'apiauth']);
$routes->put('post/(:num)', 'Post::update/$1', ['filter' => 'apiauth']);
$routes->delete('post/(:num)', 'Post::delete/$1', ['filter' => 'apiauth']);

// --- ROUTE API LOGIN (Praktikum 13) ---
$routes->post('api/login', 'Api\Auth::login');