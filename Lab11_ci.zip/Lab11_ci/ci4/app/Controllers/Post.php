<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;

class Post extends ResourceController
{
    protected $modelName = 'App\Models\ArtikelModel';
    protected $format    = 'json';

    // GET /post
    public function index()
    {
        return $this->respond([
            'status'  => 200,
            'message' => 'Success Rest API',
            'data'    => $this->model->orderBy('id', 'DESC')->findAll()
        ]);
    }

    // GET /post/(:num)
    public function show($id = null)
    {
        $data = $this->model->find($id);
        if ($data) {
            return $this->respond(['status' => 200, 'data' => $data]);
        }
        return $this->failNotFound('Artikel tidak ditemukan.');
    }

    // POST /post
    public function create()
    {
        $data = $this->request->getPost();
        if(!isset($data['judul'])) {
            return $this->fail('Judul wajib diisi.');
        }
        $data['slug'] = url_title($data['judul'], '-', true);
        $this->model->insert($data);
        return $this->respondCreated(['status' => 201, 'message' => 'Artikel berhasil dibuat via API']);
    }

    // PUT/PATCH /post/(:num)
    public function update($id = null)
    {
        $data = $this->request->getRawInput();
        if (!$this->model->find($id)) {
            return $this->failNotFound('Data target tidak valid.');
        }
        $this->model->update($id, $data);
        return $this->respond(['status' => 200, 'message' => 'Artikel berhasil diupdate via API']);
    }

    // DELETE /post/(:num)
    public function delete($id = null)
    {
        if ($this->model->find($id)) {
            $this->model->delete($id);
            return $this->respondDeleted(['status' => 200, 'message' => 'Artikel terhapus dari server']);
        }
        return $this->failNotFound('Gagal menghapus, ID tidak ada.');
    }
}