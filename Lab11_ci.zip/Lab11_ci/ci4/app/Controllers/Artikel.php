<?php

namespace App\Controllers;

use App\Models\ArtikelModel;
use App\Models\KategoriModel;

class Artikel extends BaseController
{
    // ── Public: Daftar Artikel + Filter/Search/Sort ──────────────────────
    public function index()
    {
        $title         = 'Daftar Artikel';
        $model         = new ArtikelModel();
        $kategoriModel = new KategoriModel();

        $q           = $this->request->getGet('q') ?? '';
        $kategori_id = $this->request->getGet('kategori_id') ?? '';
        $sort        = $this->request->getGet('sort') ?? 'id_desc';

        $builder = $model->table('artikel')
                         ->select('artikel.*, kategori.nama_kategori')
                         ->join('kategori', 'kategori.id_kategori = artikel.id_kategori', 'left');

        if ($q !== '') {
            $builder->like('artikel.judul', $q);
        }

        if ($kategori_id !== '') {
            $builder->where('artikel.id_kategori', $kategori_id);
        }

        switch ($sort) {
            case 'judul_asc':  $builder->orderBy('artikel.judul', 'ASC');  break;
            case 'judul_desc': $builder->orderBy('artikel.judul', 'DESC'); break;
            case 'id_asc':     $builder->orderBy('artikel.id', 'ASC');     break;
            default:           $builder->orderBy('artikel.id', 'DESC');    break;
        }

        $artikel  = $builder->findAll();
        $kategori = $kategoriModel->findAll();

        return view('artikel/index', compact('artikel', 'title', 'kategori', 'q', 'kategori_id', 'sort'));
    }

    // ── Public: Detail Artikel ───────────────────────────────────────────
    public function view($slug)
    {
        $model = new ArtikelModel();

        $artikel = $model->table('artikel')
                         ->select('artikel.*, kategori.nama_kategori')
                         ->join('kategori', 'kategori.id_kategori = artikel.id_kategori', 'left')
                         ->where(['artikel.slug' => $slug])
                         ->first();

        if (!$artikel) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $title = $artikel['judul'];
        return view('artikel/detail', compact('artikel', 'title'));
    }

    // ── Admin: Daftar Artikel + AJAX Filter/Search/Sort/Paginasi ─────────
    public function admin_index()
    {
        $title       = 'Daftar Artikel';
        $q           = $this->request->getVar('q') ?? '';
        $kategori_id = $this->request->getVar('kategori_id') ?? '';
        $page        = (int) ($this->request->getVar('page') ?? 1);
        $sort        = $this->request->getVar('sort') ?? 'id_desc';

        $model         = new ArtikelModel();
        $kategoriModel = new KategoriModel();

        $builder = $model->table('artikel')
                         ->select('artikel.*, kategori.nama_kategori')
                         ->join('kategori', 'kategori.id_kategori = artikel.id_kategori', 'left');

        if ($q !== '') {
            $builder->like('artikel.judul', $q);
        }

        if ($kategori_id !== '') {
            $builder->where('artikel.id_kategori', $kategori_id);
        }

        switch ($sort) {
            case 'judul_asc':  $builder->orderBy('artikel.judul', 'ASC');  break;
            case 'judul_desc': $builder->orderBy('artikel.judul', 'DESC'); break;
            case 'id_asc':     $builder->orderBy('artikel.id', 'ASC');     break;
            default:           $builder->orderBy('artikel.id', 'DESC');    break;
        }

        $artikel = $builder->paginate(10, 'default', $page);
        $pager   = $model->pager;

        if ($this->request->isAJAX()) {
            // Serialisasi pager manual — Pager object tidak JSON-serializable
            $pagerLinks  = [];
            $pageCount   = $pager->getPageCount('default');
            $currentPage = $pager->getCurrentPage('default');

            for ($i = 1; $i <= $pageCount; $i++) {
                $pagerLinks[] = [
                    'title'  => (string) $i,
                    'url'    => base_url("admin/artikel?q={$q}&kategori_id={$kategori_id}&sort={$sort}&page={$i}"),
                    'active' => ($i === $currentPage),
                ];
            }

            return $this->response->setJSON([
                'artikel'     => $artikel,
                'pager_links' => $pagerLinks,
            ]);
        }

        return view('artikel/admin_index', [
            'title'       => $title,
            'q'           => $q,
            'kategori_id' => $kategori_id,
            'sort'        => $sort,
            'artikel'     => $artikel,
            'pager'       => $pager,
            'kategori'    => $kategoriModel->findAll(),
        ]);
    }

    // ── Admin: Tambah Artikel ────────────────────────────────────────────
    public function add()
    {
        $kategoriModel = new KategoriModel();
        $validation    = \Config\Services::validation();

        $validation->setRules([
            'judul'       => 'required',
            'id_kategori' => 'required',
            'gambar'      => [
                'label' => 'Gambar',
                'rules' => 'uploaded[gambar]|is_image[gambar]|mime_in[gambar,image/jpg,image/jpeg,image/png,image/gif,image/webp]|max_size[gambar,2048]',
            ],
        ]);

        $isDataValid = $validation->withRequest($this->request)->run();

        if ($isDataValid) {
            $file     = $this->request->getFile('gambar');
            $namaFile = $file->getRandomName();
            $file->move(ROOTPATH . 'public/gambar', $namaFile);

            $artikelModel = new ArtikelModel();
            $artikelModel->insert([
                'judul'       => $this->request->getPost('judul'),
                'isi'         => $this->request->getPost('isi'),
                'id_kategori' => $this->request->getPost('id_kategori'),
                'status'      => $this->request->getPost('status') ?? 0,  // fix: status disimpan
                'slug'        => url_title($this->request->getPost('judul'), '-', true),
                'gambar'      => $namaFile,
            ]);
            return redirect('admin/artikel');
        }

        $title    = 'Tambah Artikel';
        $errors   = $validation->getErrors();
        $kategori = $kategoriModel->findAll();

        return view('artikel/form_add', compact('title', 'errors', 'kategori'));
    }

    // ── Admin: Edit Artikel ──────────────────────────────────────────────
    public function edit($id)
    {
        $artikelModel  = new ArtikelModel();
        $kategoriModel = new KategoriModel();

        $dataArtikel = $artikelModel->where('id', $id)->first();
        if (!$dataArtikel) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $validation = \Config\Services::validation();
        $rules      = [
            'judul'       => 'required',
            'id_kategori' => 'required',
        ];

        $file = $this->request->getFile('gambar');
        if ($file && $file->isValid() && !$file->hasMoved()) {
            $rules['gambar'] = 'is_image[gambar]|mime_in[gambar,image/jpg,image/jpeg,image/png,image/gif,image/webp]|max_size[gambar,2048]';
        }

        $validation->setRules($rules);
        $isDataValid = $validation->withRequest($this->request)->run();

        if ($isDataValid) {
            $updateData = [
                'judul'       => $this->request->getPost('judul'),
                'isi'         => $this->request->getPost('isi'),
                'id_kategori' => $this->request->getPost('id_kategori'),
                'status'      => $this->request->getPost('status') ?? $dataArtikel['status'],
                'slug'        => url_title($this->request->getPost('judul'), '-', true),
            ];

            if ($file && $file->isValid() && !$file->hasMoved()) {
                if (!empty($dataArtikel['gambar'])) {
                    $oldFile = ROOTPATH . 'public/gambar/' . $dataArtikel['gambar'];
                    if (file_exists($oldFile)) unlink($oldFile);
                }
                $namaFile             = $file->getRandomName();
                $file->move(ROOTPATH . 'public/gambar', $namaFile);
                $updateData['gambar'] = $namaFile;
            }

            $artikelModel->update($id, $updateData);
            return redirect('admin/artikel');
        }

        $data     = $dataArtikel;
        $title    = 'Edit Artikel';
        $errors   = $validation->getErrors();
        $kategori = $kategoriModel->findAll();

        return view('artikel/form_edit', compact('title', 'data', 'errors', 'kategori'));
    }

    // ── Admin: Delete Artikel ────────────────────────────────────────────
    public function delete($id)
    {
        $artikelModel = new ArtikelModel();
        $dataArtikel  = $artikelModel->where('id', $id)->first();

        if ($dataArtikel) {
            if (!empty($dataArtikel['gambar'])) {
                $filePath = ROOTPATH . 'public/gambar/' . $dataArtikel['gambar'];
                if (file_exists($filePath)) unlink($filePath);
            }
            $artikelModel->delete($id);
        }
        return redirect('admin/artikel');
    }
}