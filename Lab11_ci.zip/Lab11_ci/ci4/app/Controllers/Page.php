<?php

namespace App\Controllers;

class Page extends BaseController
{
    public function about()
    {
        return view('page/about', ['title' => 'Tentang Kami']);
    }

    public function contact()
    {
        return view('page/contact', ['title' => 'Hubungi Kami']);
    }
}
