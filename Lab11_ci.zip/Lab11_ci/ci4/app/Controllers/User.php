<?php

namespace App\Controllers;

use App\Models\UserModel;

class User extends BaseController
{
    public function login()
    {
        if (session()->get('logged_in')) {
            return redirect()->to(base_url('admin/artikel'));
        }

        if (strtolower($this->request->getMethod()) === 'post') {
            $model    = new UserModel();
            $username = $this->request->getPost('username');
            $password = $this->request->getPost('password');

            $user = $model->where('username', $username)->first();

            if ($user && password_verify($password, $user['userpassword'])) {
                session()->set([
                    'username'  => $user['username'],
                    'email'     => $user['useremail'] ?? '',
                    'logged_in' => true,
                ]);
                return redirect()->to(base_url('admin/artikel'));
            }

            return redirect()->back()->withInput()->with('error', 'Username atau Password salah!');
        }

        return view('user/login', ['title' => 'Login System']);
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to(base_url('login'));
    }
}