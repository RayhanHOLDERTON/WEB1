<?php

namespace App\Controllers;

use App\Models\ArtikelModel;

class AjaxController extends BaseController
{
    public function index()
    {
        $title = 'Kelola Artikel (AJAX)';
        return view('ajax/index', compact('title'));
    }

    public function getData()
    {
        $model = new ArtikelModel();
        $data  = $model->findAll();
        return $this->response->setJSON($data);
    }

    public function getById($id)
    {
        $model = new ArtikelModel();
        $data  = $model->find($id);

        if (!$data) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'NOT_FOUND']);
        }

        return $this->response->setJSON($data);
    }

    public function store()
    {
        $model = new ArtikelModel();
        $judul = $this->request->getPost('judul');
        $isi   = $this->request->getPost('isi');

        if (empty($judul)) {
            return $this->response->setStatusCode(422)->setJSON([
                'status'  => 'ERROR',
                'message' => 'Judul tidak boleh kosong.',
            ]);
        }

        $model->insert([
            'judul'  => $judul,
            'isi'    => $isi,
            'slug'   => url_title($judul, '-', true),
            'status' => 0,
        ]);

        return $this->response->setJSON([
            'status'  => 'OK',
            'message' => 'Artikel berhasil ditambahkan.',
        ]);
    }

    public function update($id)
    {
        $model = new ArtikelModel();
        $judul = $this->request->getPost('judul');
        $isi   = $this->request->getPost('isi');

        if (empty($judul)) {
            return $this->response->setStatusCode(422)->setJSON([
                'status'  => 'ERROR',
                'message' => 'Judul tidak boleh kosong.',
            ]);
        }

        $model->update($id, [
            'judul' => $judul,
            'isi'   => $isi,
            'slug'  => url_title($judul, '-', true),
        ]);

        return $this->response->setJSON([
            'status'  => 'OK',
            'message' => 'Artikel berhasil diperbarui.',
        ]);
    }

    public function destroy($id)
    {
        $model = new ArtikelModel();
        $model->delete($id);

        return $this->response->setJSON([
            'status'  => 'OK',
            'message' => 'Artikel berhasil dihapus.',
        ]);
    }
}