<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login · PressHub Admin</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <style>
    *,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
    :root{
      --em:#059669;--em-dark:#047857;--em-light:#ecfdf5;
      --ink:#111827;--ink-mid:#374151;--ink-muted:#6B7280;
      --border:#E5E7EB;--bg:#F3F4F6;--surface:#fff;
      --danger:#DC2626;--danger-bg:#FEF2F2;
    }
    body{font-family:'Poppins',system-ui,sans-serif;background:var(--bg);min-height:100vh;display:grid;place-items:center;padding:1.5rem;-webkit-font-smoothing:antialiased;}

    /* SHELL: form LEFT, deco RIGHT — opposite of original */
    .shell{width:100%;max-width:880px;background:var(--surface);border-radius:18px;box-shadow:0 16px 48px rgba(0,0,0,.09);overflow:hidden;display:grid;grid-template-columns:1fr 1fr;}

    /* ── FORM SIDE (LEFT) ── */
    .f-side{padding:3rem 2.5rem;display:flex;flex-direction:column;justify-content:center;}
    .f-logo{display:flex;align-items:center;gap:8px;margin-bottom:2.5rem;}
    .f-logo-box{width:34px;height:34px;background:var(--em);border-radius:9px;display:flex;align-items:center;justify-content:center;font-weight:900;color:#fff;font-size:15px;}
    .f-logo-name{font-weight:700;font-size:.95rem;color:var(--ink);}
    .f-logo-name span{color:var(--em);}
    .f-title{font-size:1.6rem;font-weight:800;color:var(--ink);margin-bottom:.3rem;letter-spacing:-.5px;}
    .f-sub{font-size:.85rem;color:var(--ink-muted);margin-bottom:2rem;}
    .f-group{margin-bottom:1.1rem;}
    .f-label{display:block;font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--ink-muted);margin-bottom:6px;}
    .f-input{width:100%;padding:11px 14px;border:1.5px solid var(--border);border-radius:9px;font-size:.9rem;font-family:inherit;color:var(--ink);background:#fafafa;outline:none;transition:border .2s,box-shadow .2s;}
    .f-input:focus{border-color:var(--em);background:#fff;box-shadow:0 0 0 3px rgba(5,150,105,.1);}
    .f-err{background:var(--danger-bg);border:1px solid #fecaca;color:var(--danger);border-radius:9px;padding:11px 14px;font-size:.83rem;margin-bottom:1.25rem;display:flex;align-items:center;gap:7px;}
    .f-btn{width:100%;padding:13px;background:var(--em);color:#fff;border:none;border-radius:9px;font-size:.95rem;font-weight:700;font-family:inherit;cursor:pointer;margin-top:.25rem;transition:background .2s,transform .15s;}
    .f-btn:hover{background:var(--em-dark);transform:translateY(-1px);}
    .f-btn:active{transform:translateY(0);}
    .f-back{display:block;text-align:center;margin-top:1.25rem;font-size:.83rem;color:var(--ink-muted);text-decoration:none;transition:color .2s;}
    .f-back:hover{color:var(--em);}

    /* ── DECO SIDE (RIGHT) ── */
    .d-side{background:linear-gradient(155deg,#022c22 0%,#064e3b 50%,#059669 100%);padding:3rem 2.5rem;display:flex;flex-direction:column;justify-content:space-between;position:relative;overflow:hidden;}
    .d-side::before{content:'';position:absolute;width:260px;height:260px;background:radial-gradient(circle,rgba(255,255,255,.08) 0%,transparent 70%);bottom:-60px;right:-60px;border-radius:50%;}
    .d-side::after{content:'';position:absolute;width:160px;height:160px;background:radial-gradient(circle,rgba(255,255,255,.06) 0%,transparent 70%);top:40px;left:-40px;border-radius:50%;}
    .d-top{position:relative;z-index:1;}
    .d-icon{font-size:2.8rem;margin-bottom:1.5rem;}
    .d-title{font-size:1.6rem;font-weight:800;color:#fff;line-height:1.3;margin-bottom:.9rem;letter-spacing:-.5px;}
    .d-title em{color:#6ee7b7;font-style:normal;}
    .d-desc{font-size:.85rem;color:rgba(255,255,255,.55);line-height:1.75;}
    .d-pills{display:flex;flex-direction:column;gap:.75rem;position:relative;z-index:1;}
    .d-pill{display:flex;align-items:center;gap:9px;font-size:.8rem;color:rgba(255,255,255,.6);}
    .d-pill-dot{width:6px;height:6px;border-radius:50%;background:#6ee7b7;flex-shrink:0;}
    .d-copy{font-size:.72rem;color:rgba(255,255,255,.2);position:relative;z-index:1;}

    @media(max-width:600px){.shell{grid-template-columns:1fr;max-width:420px;}.d-side{display:none;}.f-side{padding:2.5rem 1.75rem;}}
  </style>
</head>
<body>
<div class="shell">

  <!-- FORM SIDE: LEFT -->
  <div class="f-side">
    <div class="f-logo">
      <div class="f-logo-box">P</div>
      <span class="f-logo-name">Press<span>Hub</span></span>
    </div>

    <h1 class="f-title">Masuk ke Admin</h1>
    <p class="f-sub">Gunakan akun administrator untuk mengakses panel.</p>

    <?php if (session()->getFlashdata('error')): ?>
    <div class="f-err">⚠️ <?= session()->getFlashdata('error') ?></div>
    <?php endif; ?>

    <form action="<?= base_url('login') ?>" method="post" autocomplete="off">
      <?= csrf_field() ?>
      <div class="f-group">
        <label class="f-label" for="username">Username</label>
        <input class="f-input" type="text" id="username" name="username" placeholder="Masukkan username" required autofocus>
      </div>
      <div class="f-group">
        <label class="f-label" for="password">Password</label>
        <input class="f-input" type="password" id="password" name="password" placeholder="••••••••" required>
      </div>
      <button type="submit" class="f-btn">Masuk ke Dashboard</button>
    </form>
    <a class="f-back" href="<?= base_url('/') ?>">← Kembali ke Beranda</a>
  </div>

  <!-- DECO SIDE: RIGHT -->
  <div class="d-side">
    <div class="d-top">
      <div class="d-icon">📰</div>
      <h2 class="d-title">Kelola konten<br>dengan <em>efisien</em></h2>
      <p class="d-desc">Platform CMS berbasis CodeIgniter 4 dengan fitur artikel, AJAX CRUD, dan REST API terintegrasi.</p>
    </div>
    <div class="d-pills">
      <div class="d-pill"><div class="d-pill-dot"></div>Manajemen Artikel & Kategori</div>
      <div class="d-pill"><div class="d-pill-dot"></div>AJAX CRUD Real-time</div>
      <div class="d-pill"><div class="d-pill-dot"></div>REST API + Authentication</div>
      <div class="d-pill"><div class="d-pill-dot"></div>Upload Gambar Terintegrasi</div>
    </div>
    <div class="d-copy">&copy; <?= date('Y') ?> Universitas Pelita Bangsa</div>
  </div>

</div>
</body>
</html>
