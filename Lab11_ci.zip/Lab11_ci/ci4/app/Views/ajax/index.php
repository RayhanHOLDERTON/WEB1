<?= $this->extend('layout/admin') ?>
<?= $this->section('admin_content') ?>

<div class="adm-page-head">
  <h1>AJAX CRUD Artikel</h1>
  <p class="sub">Kelola artikel secara real-time tanpa reload halaman.</p>
</div>

<div class="adm-card">
  <div class="adm-card-head">
    <h6>Data Artikel</h6>
    <button class="btn-em" id="btnTambah"><i class="fa-solid fa-plus"></i> Tambah</button>
  </div>
  <div style="overflow-x:auto;">
    <table class="adm-table" id="artikelTable">
      <thead>
        <tr>
          <th style="width:48px;">#</th>
          <th>Judul</th>
          <th style="width:100px;">Status</th>
          <th style="width:140px;text-align:right;">Aksi</th>
        </tr>
      </thead>
      <tbody id="tableBody">
        <tr><td colspan="4" style="text-align:center;padding:40px;color:#9CA3AF;">Memuat data…</td></tr>
      </tbody>
    </table>
  </div>
</div>

<!-- Modal Tambah/Edit -->
<div class="modal fade" id="modalForm" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content" style="border-radius:12px;border:1px solid #E5E7EB;">
      <div class="modal-header" style="border-bottom:1px solid #F3F4F6;padding:.9rem 1.25rem;">
        <h6 class="modal-title fw-bold" id="modalTitle" style="font-size:.9rem;">Tambah Artikel</h6>
        <button type="button" class="btn-close" data-bs-dismiss="modal" style="font-size:.8rem;"></button>
      </div>
      <div class="modal-body" style="padding:1.25rem;">
        <input type="hidden" id="editId">
        <div id="formError" class="adm-alert-err" style="display:none;"></div>
        <div style="margin-bottom:1rem;">
          <label class="adm-label">Judul Artikel</label>
          <input type="text" id="inputJudul" class="adm-input" placeholder="Masukkan judul...">
        </div>
        <div>
          <label class="adm-label">Isi Artikel</label>
          <textarea id="inputIsi" class="adm-input" rows="5" placeholder="Tulis isi artikel..."></textarea>
        </div>
      </div>
      <div class="modal-footer" style="border-top:1px solid #F3F4F6;padding:.9rem 1.25rem;gap:.6rem;">
        <button type="button" class="btn-sec" data-bs-dismiss="modal">Batal</button>
        <button type="button" class="btn-em" id="btnSimpan"><i class="fa-solid fa-floppy-disk"></i> Simpan</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal Hapus -->
<div class="modal fade" id="modalHapus" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered" style="max-width:400px;">
    <div class="modal-content" style="border-radius:12px;border:1px solid #E5E7EB;">
      <div class="modal-header" style="border-bottom:1px solid #F3F4F6;padding:.9rem 1.25rem;">
        <h6 class="modal-title fw-bold" style="font-size:.9rem;">Konfirmasi Hapus</h6>
        <button type="button" class="btn-close" data-bs-dismiss="modal" style="font-size:.8rem;"></button>
      </div>
      <div class="modal-body" style="padding:1.25rem;">
        <p style="font-size:.85rem;color:#6B7280;margin:0;">Yakin ingin menghapus artikel <strong id="deleteTitle"></strong>? Tindakan ini tidak bisa dibatalkan.</p>
      </div>
      <div class="modal-footer" style="border-top:1px solid #F3F4F6;padding:.9rem 1.25rem;gap:.6rem;">
        <button type="button" class="btn-sec" data-bs-dismiss="modal">Batal</button>
        <button type="button" class="btn-dl" id="btnConfirmDelete" style="padding:8px 16px;font-size:.82rem;"><i class="fa-solid fa-trash"></i> Hapus</button>
      </div>
    </div>
  </div>
</div>

<script>
const BASE = '<?= base_url() ?>';
let deleteTarget = null, modalForm, modalHapus;

document.addEventListener('DOMContentLoaded', function(){
  modalForm  = new bootstrap.Modal(document.getElementById('modalForm'));
  modalHapus = new bootstrap.Modal(document.getElementById('modalHapus'));
  loadData();

  document.getElementById('btnTambah').addEventListener('click', function(){
    document.getElementById('modalTitle').textContent = 'Tambah Artikel Baru';
    document.getElementById('editId').value = '';
    document.getElementById('inputJudul').value = '';
    document.getElementById('inputIsi').value = '';
    document.getElementById('formError').style.display = 'none';
    modalForm.show();
  });
  document.getElementById('btnSimpan').addEventListener('click', saveArtikel);
  document.getElementById('btnConfirmDelete').addEventListener('click', deleteArtikel);
});

function loadData(){
  fetch(BASE+'admin/ajax/data').then(r=>r.json()).then(data=>{
    const tb = document.getElementById('tableBody');
    if(!data||data.length===0){
      tb.innerHTML='<tr><td colspan="4" style="text-align:center;padding:40px;color:#9CA3AF;">Belum ada artikel.</td></tr>';
      return;
    }
    tb.innerHTML = data.map((row,i)=>`
      <tr>
        <td style="color:#9CA3AF;font-size:.78rem;">${i+1}</td>
        <td>
          <div style="font-weight:600;color:#111827;font-size:.83rem;">${row.judul}</div>
          <div style="font-size:.72rem;color:#9CA3AF;">${(row.isi||'').substring(0,65)}${row.isi&&row.isi.length>65?'…':''}</div>
        </td>
        <td>${row.status==1?'<span class="bpub">Aktif</span>':'<span class="bdraft">Draft</span>'}</td>
        <td style="text-align:right;">
          <button class="btn-ed" onclick="editArtikel(${row.id})">Edit</button>
          <button class="btn-dl" onclick="confirmDelete(${row.id},'${row.judul.replace(/'/g,"\\'")}')">Hapus</button>
        </td>
      </tr>`).join('');
  }).catch(()=>{
    document.getElementById('tableBody').innerHTML='<tr><td colspan="4" style="text-align:center;padding:40px;color:#DC2626;">Gagal memuat data.</td></tr>';
  });
}

function editArtikel(id){
  fetch(BASE+'admin/ajax/get/'+id).then(r=>r.json()).then(row=>{
    document.getElementById('modalTitle').textContent='Edit Artikel';
    document.getElementById('editId').value=row.id;
    document.getElementById('inputJudul').value=row.judul;
    document.getElementById('inputIsi').value=row.isi||'';
    document.getElementById('formError').style.display='none';
    modalForm.show();
  });
}

function saveArtikel(){
  const id=document.getElementById('editId').value;
  const judul=document.getElementById('inputJudul').value.trim();
  const isi=document.getElementById('inputIsi').value.trim();
  const errEl=document.getElementById('formError');
  if(!judul){errEl.textContent='Judul tidak boleh kosong.';errEl.style.display='block';return;}
  errEl.style.display='none';
  const form=new FormData();form.append('judul',judul);form.append('isi',isi);
  const url=id?BASE+'admin/ajax/update/'+id:BASE+'admin/ajax/store';
  fetch(url,{method:'POST',body:form}).then(r=>r.json()).then(res=>{
    if(res.status==='OK'){modalForm.hide();loadData();showToast(id?'Artikel diperbarui':'Artikel ditambahkan','ok');}
    else{errEl.textContent=res.message||'Terjadi kesalahan.';errEl.style.display='block';}
  });
}

function confirmDelete(id,judul){
  deleteTarget=id;
  document.getElementById('deleteTitle').textContent=judul;
  modalHapus.show();
}

function deleteArtikel(){
  if(!deleteTarget)return;
  fetch(BASE+'admin/ajax/delete/'+deleteTarget).then(r=>r.json()).then(()=>{
    modalHapus.hide();deleteTarget=null;loadData();showToast('Artikel dihapus','ok');
  });
}
</script>

<?= $this->endSection() ?>
