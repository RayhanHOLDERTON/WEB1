<?php
/**
 * DEPRECATED: File ini tidak lagi digunakan.
 * Semua tampilan admin kini menggunakan sistem extend/section dengan layout/admin.php
 * Lihat: app/Views/layout/admin.php
 */
