<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= esc($title ?? 'Admin') ?> · PressHub Admin</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
  <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
  <style>
    /* ══════════════════════════════════════
       PRESSHUB ADMIN — Horizontal Layout
       Theme: Emerald + White Topbar
    ══════════════════════════════════════ */
    :root {
      --font:       'Poppins', system-ui, sans-serif;
      --em:         #059669;
      --em-dark:    #047857;
      --em-light:   #ecfdf5;
      --em-mid:     #d1fae5;
      --ink:        #111827;
      --ink-mid:    #374151;
      --ink-muted:  #6B7280;
      --ink-subtle: #9CA3AF;
      --bg:         #F3F4F6;
      --surface:    #ffffff;
      --border:     #E5E7EB;
      --border-lt:  #F9FAFB;
      --danger:     #DC2626;
      --danger-bg:  #FEF2F2;
      --warn:       #D97706;
      --radius:     10px;
    }
    *,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
    html,body{height:100%;}
    body{font-family:var(--font);background:var(--bg);color:var(--ink-mid);-webkit-font-smoothing:antialiased;display:flex;flex-direction:column;min-height:100vh;}

    /* ── TOP NAVBAR ──────────────────────── */
    #adm-top{
      background:var(--surface);
      border-bottom:1px solid var(--border);
      height:60px;
      display:flex;
      align-items:center;
      padding:0 1.5rem;
      gap:1rem;
      position:sticky;top:0;z-index:500;
      box-shadow:0 1px 6px rgba(0,0,0,.06);
    }
    .adm-brand{display:flex;align-items:center;gap:9px;text-decoration:none;flex-shrink:0;margin-right:.75rem;}
    .adm-brand-icon{width:34px;height:34px;background:var(--em);border-radius:9px;display:flex;align-items:center;justify-content:center;font-weight:900;color:#fff;font-size:14px;}
    .adm-brand-name{font-weight:700;font-size:.95rem;color:var(--ink);letter-spacing:-.2px;}
    .adm-brand-name span{color:var(--em);}

    /* horizontal nav */
    .adm-nav{display:flex;align-items:center;gap:2px;flex:1;}
    .adm-nav a{display:inline-flex;align-items:center;gap:7px;padding:7px 13px;color:var(--ink-muted);text-decoration:none;font-size:.82rem;font-weight:500;border-radius:8px;transition:all .18s;}
    .adm-nav a:hover{color:var(--ink);background:var(--bg);}
    .adm-nav a.adm-active{color:var(--em);background:var(--em-light);font-weight:600;}
    .adm-nav a i{font-size:.8rem;width:14px;text-align:center;}

    /* topbar right */
    .adm-top-right{display:flex;align-items:center;gap:.75rem;flex-shrink:0;}
    .adm-date{font-size:.75rem;color:var(--ink-subtle);}
    .adm-avatar{width:34px;height:34px;background:var(--em);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font-size:.8rem;font-weight:700;}
    .adm-logout{display:inline-flex;align-items:center;gap:5px;padding:6px 12px;background:var(--danger-bg);color:var(--danger);font-size:.78rem;font-weight:600;border-radius:7px;text-decoration:none;transition:all .18s;}
    .adm-logout:hover{background:#fee2e2;color:var(--danger);}

    /* ── CONTENT AREA ───────────────────── */
    #adm-content{flex:1;padding:1.75rem;max-width:1400px;width:100%;margin:0 auto;}

    /* ── PAGE HEADING ───────────────────── */
    .adm-page-head{margin-bottom:1.5rem;}
    .adm-page-head h1{font-size:1.3rem;font-weight:700;color:var(--ink);margin-bottom:.2rem;}
    .adm-page-head .sub{font-size:.8rem;color:var(--ink-subtle);}

    /* ── CARD ───────────────────────────── */
    .adm-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);box-shadow:0 1px 4px rgba(0,0,0,.04);overflow:hidden;}
    .adm-card-head{padding:.9rem 1.25rem;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;gap:1rem;}
    .adm-card-head h6{font-size:.85rem;font-weight:700;color:var(--ink);margin:0;}

    /* ── FILTER BAR ─────────────────────── */
    .filter-bar{display:flex;gap:.6rem;flex-wrap:wrap;margin-bottom:1.25rem;}
    .filter-bar input,.filter-bar select{padding:8px 12px;border:1px solid var(--border);border-radius:8px;font-size:.82rem;font-family:var(--font);background:var(--surface);color:var(--ink-mid);outline:none;transition:border .2s;}
    .filter-bar input:focus,.filter-bar select:focus{border-color:var(--em);box-shadow:0 0 0 3px rgba(5,150,105,.1);}

    /* ── TABLE ──────────────────────────── */
    .adm-table{width:100%;border-collapse:collapse;font-size:.835rem;}
    .adm-table thead tr{background:#fafafa;}
    .adm-table th{padding:10px 14px;text-align:left;font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:var(--ink-subtle);border-bottom:1px solid var(--border);white-space:nowrap;}
    .adm-table td{padding:13px 14px;border-bottom:1px solid #f3f4f6;vertical-align:middle;}
    .adm-table tbody tr:last-child td{border-bottom:none;}
    .adm-table tbody tr:hover td{background:#fafafa;}

    /* ── BADGES ─────────────────────────── */
    .bpub{display:inline-flex;align-items:center;gap:5px;padding:3px 10px;border-radius:99px;font-size:.7rem;font-weight:700;background:#ecfdf5;color:#065f46;}
    .bpub::before{content:'';width:5px;height:5px;border-radius:50%;background:#059669;flex-shrink:0;}
    .bdraft{display:inline-flex;align-items:center;gap:5px;padding:3px 10px;border-radius:99px;font-size:.7rem;font-weight:700;background:#fffbeb;color:#92400e;}
    .bdraft::before{content:'';width:5px;height:5px;border-radius:50%;background:#f59e0b;flex-shrink:0;}

    /* ── BUTTONS ────────────────────────── */
    .btn-em{display:inline-flex;align-items:center;gap:6px;padding:8px 16px;background:var(--em);color:#fff;border:none;border-radius:8px;font-size:.82rem;font-weight:600;font-family:var(--font);cursor:pointer;transition:background .2s;text-decoration:none;}
    .btn-em:hover{background:var(--em-dark);color:#fff;}
    .btn-sec{display:inline-flex;align-items:center;gap:6px;padding:8px 14px;background:var(--bg);color:var(--ink-mid);border:1px solid var(--border);border-radius:8px;font-size:.82rem;font-weight:600;font-family:var(--font);cursor:pointer;transition:all .18s;text-decoration:none;}
    .btn-sec:hover{background:var(--border);color:var(--ink);}
    .btn-ed{padding:5px 11px;background:var(--em-light);color:var(--em-dark);border:none;border-radius:6px;font-size:.75rem;font-weight:600;cursor:pointer;font-family:var(--font);transition:background .18s;text-decoration:none;display:inline-block;}
    .btn-ed:hover{background:var(--em-mid);}
    .btn-dl{padding:5px 11px;background:var(--danger-bg);color:var(--danger);border:none;border-radius:6px;font-size:.75rem;font-weight:600;cursor:pointer;font-family:var(--font);transition:background .18s;}
    .btn-dl:hover{background:#fee2e2;}

    /* ── FORM ELEMENTS ──────────────────── */
    .adm-label{display:block;font-size:.72rem;font-weight:700;color:var(--ink-muted);text-transform:uppercase;letter-spacing:.5px;margin-bottom:6px;}
    .adm-input{width:100%;padding:10px 13px;border:1.5px solid var(--border);border-radius:8px;font-size:.88rem;font-family:var(--font);color:var(--ink);background:var(--surface);outline:none;transition:border .2s,box-shadow .2s;}
    .adm-input:focus{border-color:var(--em);box-shadow:0 0 0 3px rgba(5,150,105,.1);}
    textarea.adm-input{resize:vertical;min-height:200px;}
    select.adm-input{appearance:auto;}

    /* ── ALERT ──────────────────────────── */
    .adm-alert-err{background:var(--danger-bg);border:1px solid #fecaca;color:var(--danger);border-radius:8px;padding:11px 14px;font-size:.83rem;margin-bottom:1rem;}

    /* ── PAGINATION ─────────────────────── */
    .pager{display:flex;gap:4px;flex-wrap:wrap;margin-top:1rem;}
    .pager a,.pager span{display:inline-block;padding:5px 11px;border:1px solid var(--border);border-radius:6px;font-size:.78rem;text-decoration:none;color:var(--ink-mid);transition:all .18s;}
    .pager a:hover{background:var(--em);color:#fff;border-color:var(--em);}
    .pager .active{background:var(--em);color:#fff;border-color:var(--em);font-weight:700;}

    /* ── TOAST ──────────────────────────── */
    #toast-box{position:fixed;bottom:1.5rem;right:1.5rem;z-index:9999;display:flex;flex-direction:column;gap:.5rem;}
    .toast-item{background:var(--ink);color:#fff;padding:11px 16px;border-radius:9px;font-size:.83rem;font-weight:500;min-width:230px;box-shadow:0 6px 20px rgba(0,0,0,.18);display:flex;align-items:center;gap:9px;animation:tin .28s cubic-bezier(.16,1,.3,1);}
    .toast-item.tok{border-left:4px solid #10b981;}
    .toast-item.terr{border-left:4px solid var(--danger);}
    @keyframes tin{from{opacity:0;transform:translateX(100%)}to{opacity:1;transform:translateX(0)}}
    .toast-item.tout{opacity:0;transform:translateX(40px);transition:all .22s;}
  </style>
</head>
<body>

<!-- TOPBAR -->
<header id="adm-top">
  <a class="adm-brand" href="<?= base_url('/') ?>" target="_blank">
    <div class="adm-brand-icon">P</div>
    <span class="adm-brand-name">Press<span>Hub</span></span>
  </a>

  <nav class="adm-nav">
    <a href="<?= base_url('admin/artikel') ?>"
       class="<?= url_is('admin/artikel') || url_is('admin/artikel/add') || url_is('admin/artikel/edit/*') ? 'adm-active':'' ?>">
      <i class="fa-solid fa-newspaper"></i>Artikel
    </a>
    <a href="<?= base_url('admin/ajax') ?>"
       class="<?= url_is('admin/ajax*') ? 'adm-active':'' ?>">
      <i class="fa-solid fa-bolt"></i>AJAX CRUD
    </a>
    <a href="<?= base_url('/') ?>" target="_blank">
      <i class="fa-solid fa-arrow-up-right-from-square"></i>Lihat Website
    </a>
  </nav>

  <div class="adm-top-right">
    <span class="adm-date d-none d-md-block">
      <i class="fa-regular fa-calendar me-1"></i><?= date('d M Y') ?>
    </span>
    <div class="adm-avatar">A</div>
    <a href="<?= base_url('logout') ?>" class="adm-logout">
      <i class="fa-solid fa-power-off"></i>Keluar
    </a>
  </div>
</header>

<!-- CONTENT -->
<main id="adm-content">
  <?= $this->renderSection('admin_content') ?>
</main>

<div id="toast-box"></div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
function showToast(msg, type='ok'){
  const el = document.createElement('div');
  el.className='toast-item '+(type==='ok'?'tok':'terr');
  el.innerHTML=(type==='ok'?'✅':'❌')+' '+msg;
  document.getElementById('toast-box').appendChild(el);
  setTimeout(()=>{el.classList.add('tout');setTimeout(()=>el.remove(),240);},3200);
}
</script>
</body>
</html>
