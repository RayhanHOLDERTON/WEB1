<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= esc($title ?? 'Artikel') ?> — PressHub</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
  <style>
    :root {
      --font:     'Poppins', system-ui, sans-serif;
      --emerald:  #059669;
      --em-dark:  #047857;
      --em-light: #ecfdf5;
      --em-mid:   #d1fae5;
      --ink:      #111827;
      --ink-mid:  #374151;
      --ink-muted:#6B7280;
      --border:   #E5E7EB;
      --bg:       #F9FAFB;
      --surface:  #ffffff;
      --radius:   10px;
    }
    *,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
    html{scroll-behavior:smooth;}
    body{font-family:var(--font);background:var(--bg);color:var(--ink);display:flex;flex-direction:column;min-height:100vh;-webkit-font-smoothing:antialiased;}

    /* TOPBAR */
    .ph-nav{background:var(--emerald);position:sticky;top:0;z-index:999;}
    .ph-nav-inner{max-width:1180px;margin:0 auto;padding:0 1.25rem;height:60px;display:flex;align-items:center;gap:1.5rem;}
    .ph-brand{display:flex;align-items:center;gap:9px;text-decoration:none;}
    .ph-brand-box{width:32px;height:32px;background:#fff;border-radius:8px;display:flex;align-items:center;justify-content:center;font-weight:900;color:var(--emerald);font-size:14px;}
    .ph-brand-name{font-weight:700;font-size:1rem;color:#fff;letter-spacing:-.2px;}
    .ph-nav-links{display:flex;align-items:center;gap:2px;flex:1;}
    .ph-nav-links a{display:inline-block;padding:6px 12px;color:rgba(255,255,255,.75);text-decoration:none;font-size:.85rem;font-weight:500;border-radius:6px;transition:all .18s;}
    .ph-nav-links a:hover{color:#fff;background:rgba(255,255,255,.12);}
    .ph-nav-links a.active{color:#fff;background:rgba(255,255,255,.18);font-weight:600;}
    .ph-nav-cta{padding:7px 16px;background:#fff;color:var(--em-dark);font-size:.82rem;font-weight:700;border-radius:6px;text-decoration:none;transition:all .2s;flex-shrink:0;}
    .ph-nav-cta:hover{background:var(--em-light);color:var(--em-dark);}

    /* CONTENT */
    .ph-main{flex:1;max-width:1180px;margin:0 auto;width:100%;padding:2.5rem 1.25rem;}

    /* FOOTER */
    .ph-footer{background:var(--ink);color:rgba(255,255,255,.6);padding:2rem 1.25rem;margin-top:auto;}
    .ph-footer-inner{max-width:1180px;margin:0 auto;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:1rem;}
    .ph-footer-brand{font-weight:700;color:#fff;font-size:.95rem;}
    .ph-footer-links{display:flex;gap:1.25rem;list-style:none;}
    .ph-footer-links a{color:rgba(255,255,255,.45);text-decoration:none;font-size:.8rem;transition:color .2s;}
    .ph-footer-links a:hover{color:#fff;}
    .ph-footer-copy{text-align:center;font-size:.75rem;color:rgba(255,255,255,.25);margin-top:1.5rem;padding-top:1.25rem;border-top:1px solid rgba(255,255,255,.07);max-width:1180px;margin:1.5rem auto 0;}
  </style>
</head>
<body>

<nav class="ph-nav">
  <div class="ph-nav-inner">
    <a class="ph-brand" href="<?= base_url() ?>">
      <div class="ph-brand-box">P</div>
      <span class="ph-brand-name">PressHub</span>
    </a>
    <div class="ph-nav-links">
      <a href="<?= base_url() ?>"       class="<?= (url_is('') || url_is('/')) ? 'active':'' ?>">Beranda</a>
      <a href="<?= base_url('artikel') ?>" class="<?= url_is('artikel*') ? 'active':'' ?>">Artikel</a>
      <a href="<?= base_url('about') ?>"   class="<?= url_is('about*') ? 'active':'' ?>">Tentang</a>
      <a href="<?= base_url('contact') ?>" class="<?= url_is('contact*') ? 'active':'' ?>">Kontak</a>
    </div>
    <a class="ph-nav-cta" href="<?= base_url('admin/artikel') ?>">
      <i class="fa-solid fa-table-columns me-1" style="font-size:.75rem;"></i>Admin
    </a>
  </div>
</nav>

<div class="ph-main">
  <?= $this->renderSection('content') ?>
</div>

<footer class="ph-footer">
  <div class="ph-footer-inner">
    <span class="ph-footer-brand">PressHub</span>
    <ul class="ph-footer-links">
      <li><a href="<?= base_url() ?>">Beranda</a></li>
      <li><a href="<?= base_url('artikel') ?>">Artikel</a></li>
      <li><a href="<?= base_url('about') ?>">Tentang</a></li>
      <li><a href="<?= base_url('contact') ?>">Kontak</a></li>
    </ul>
  </div>
  <p class="ph-footer-copy">&copy; <?= date('Y') ?> PressHub · Universitas Pelita Bangsa · Pemrograman Web 2</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
