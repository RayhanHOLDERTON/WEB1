<div style="background:#fff;border:1px solid #E5E7EB;border-radius:12px;padding:1.25rem;">
  <h3 style="font-size:.88rem;font-weight:700;color:#111827;margin-bottom:1rem;padding-bottom:.75rem;border-bottom:2px solid #ecfdf5;position:relative;">
    Artikel Terkini
    <span style="position:absolute;left:0;bottom:-2px;width:36px;height:2px;background:#059669;border-radius:99px;"></span>
  </h3>
  <ul style="list-style:none;padding:0;margin:0;">
    <?php if(!empty($artikel)): ?>
      <?php foreach($artikel as $row): ?>
      <li style="border-bottom:1px dashed #F3F4F6;">
        <a href="<?= base_url('/artikel/'.esc($row['slug']??$row['id'])) ?>"
           style="display:flex;align-items:flex-start;gap:9px;padding:10px 0;text-decoration:none;color:#374151;font-size:.83rem;font-weight:500;line-height:1.5;transition:color .2s;">
          <i class="fa-solid fa-chevron-right" style="margin-top:3px;font-size:.65rem;color:#059669;flex-shrink:0;"></i>
          <span><?= esc($row['judul']) ?></span>
        </a>
      </li>
      <?php endforeach; ?>
    <?php else: ?>
      <li style="text-align:center;padding:1.25rem;color:#9CA3AF;font-size:.82rem;">Belum ada artikel.</li>
    <?php endif; ?>
  </ul>
</div>
