<?= $this->extend('layout/main') ?>
<?= $this->section('content') ?>

<div style="max-width:800px;margin:0 auto;">
  <div style="margin-bottom:2.5rem;">
    <span style="font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;color:#059669;">Kontak</span>
    <h1 style="font-size:2.2rem;font-weight:800;color:#111827;letter-spacing:-.5px;margin-top:.4rem;margin-bottom:.75rem;">Ada Pertanyaan?</h1>
    <div style="width:40px;height:4px;background:#059669;border-radius:99px;"></div>
  </div>

  <div style="display:grid;grid-template-columns:1fr 1.4fr;gap:1.75rem;align-items:start;">
    <div>
      <p style="font-size:.9rem;color:#6B7280;line-height:1.75;margin-bottom:1.5rem;">Kami terbuka untuk pertanyaan, masukan, atau kolaborasi terkait platform ini.</p>
      <?php
      $contacts=[
        ['📍','Alamat','Jl. Inspeksi Kalimalang No.1, Bekasi'],
        ['✉️','Email','labweb@pelitabangsa.ac.id'],
        ['🌐','Website','universitas.pelitabangsa.ac.id'],
      ];
      foreach($contacts as $c):
      ?>
      <div style="display:flex;gap:11px;align-items:flex-start;margin-bottom:1rem;">
        <span style="font-size:1.1rem;margin-top:2px;"><?= $c[0] ?></span>
        <div>
          <div style="font-size:.68rem;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:#9CA3AF;"><?= $c[1] ?></div>
          <div style="font-size:.88rem;color:#111827;font-weight:500;"><?= $c[2] ?></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>

    <div style="background:#fff;border:1px solid #E5E7EB;border-radius:14px;padding:1.75rem;box-shadow:0 2px 10px rgba(0,0,0,.04);">
      <h3 style="font-size:.95rem;font-weight:700;color:#111827;margin-bottom:1.25rem;">Kirim Pesan</h3>
      <div style="margin-bottom:1rem;">
        <label style="display:block;font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:#6B7280;margin-bottom:5px;">Nama</label>
        <input type="text" placeholder="Nama Anda" style="width:100%;padding:9px 12px;border:1.5px solid #E5E7EB;border-radius:8px;font-size:.88rem;outline:none;font-family:inherit;">
      </div>
      <div style="margin-bottom:1rem;">
        <label style="display:block;font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:#6B7280;margin-bottom:5px;">Email</label>
        <input type="email" placeholder="email@contoh.com" style="width:100%;padding:9px 12px;border:1.5px solid #E5E7EB;border-radius:8px;font-size:.88rem;outline:none;font-family:inherit;">
      </div>
      <div style="margin-bottom:1.25rem;">
        <label style="display:block;font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:#6B7280;margin-bottom:5px;">Pesan</label>
        <textarea rows="4" placeholder="Tulis pesan di sini..." style="width:100%;padding:9px 12px;border:1.5px solid #E5E7EB;border-radius:8px;font-size:.88rem;outline:none;resize:vertical;font-family:inherit;"></textarea>
      </div>
      <button style="width:100%;padding:11px;background:#059669;color:#fff;border:none;border-radius:8px;font-size:.9rem;font-weight:700;cursor:pointer;font-family:inherit;transition:background .2s;" onmouseover="this.style.background='#047857'" onmouseout="this.style.background='#059669'">
        Kirim Pesan
      </button>
    </div>
  </div>
</div>

<?= $this->endSection() ?>
