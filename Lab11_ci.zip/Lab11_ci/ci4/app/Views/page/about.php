<?= $this->extend('layout/main') ?>
<?= $this->section('content') ?>

<div style="max-width:860px;margin:0 auto;">
  <div style="margin-bottom:2.5rem;">
    <span style="font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;color:#059669;">Tentang Kami</span>
    <h1 style="font-size:2.2rem;font-weight:800;color:#111827;letter-spacing:-.5px;margin-top:.4rem;margin-bottom:.75rem;">
      Portal Artikel Digital
    </h1>
    <div style="width:40px;height:4px;background:#059669;border-radius:99px;"></div>
  </div>

  <div style="display:grid;grid-template-columns:1fr 1fr;gap:1.5rem;margin-bottom:2.5rem;">
    <div style="background:#fff;border:1px solid #E5E7EB;border-radius:12px;padding:1.75rem;border-top:4px solid #059669;">
      <div style="font-size:1.6rem;margin-bottom:.9rem;">🏫</div>
      <h3 style="font-size:1rem;font-weight:700;color:#111827;margin-bottom:.5rem;">Tentang Platform</h3>
      <p style="font-size:.88rem;color:#6B7280;line-height:1.75;">
        PressHub adalah portal artikel digital yang dibangun menggunakan <strong>CodeIgniter 4</strong>
        sebagai proyek praktikum Pemrograman Web 2 di Universitas Pelita Bangsa.
      </p>
    </div>
    <div style="background:#fff;border:1px solid #E5E7EB;border-radius:12px;padding:1.75rem;border-top:4px solid #059669;">
      <div style="font-size:1.6rem;margin-bottom:.9rem;">⚙️</div>
      <h3 style="font-size:1rem;font-weight:700;color:#111827;margin-bottom:.5rem;">Tujuan Pengembangan</h3>
      <p style="font-size:.88rem;color:#6B7280;line-height:1.75;">
        Mendemonstrasikan implementasi MVC, CRUD, autentikasi, upload file, hingga
        REST API dalam satu platform terpadu yang bersih dan mudah dikembangkan.
      </p>
    </div>
  </div>

  <div style="background:#fff;border:1px solid #E5E7EB;border-radius:12px;padding:1.75rem;margin-bottom:2.5rem;">
    <h3 style="font-size:1rem;font-weight:700;color:#111827;margin-bottom:1.25rem;">🛠️ Teknologi yang Digunakan</h3>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:.75rem;">
      <?php
      $stack=[
        ['CodeIgniter 4','PHP MVC Framework','⚡','#ecfdf5','#065f46'],
        ['Bootstrap 5.3','CSS UI Framework','🎨','#eff6ff','#1e40af'],
        ['MySQL','Database Engine','🗄️','#f0fdf4','#166534'],
        ['jQuery 3.7','AJAX & DOM','🔁','#fef9c3','#854d0e'],
        ['REST API','Modul Praktikum 10','📡','#fdf4ff','#7e22ce'],
        ['PHP 8+','Backend Language','🐘','#fff7ed','#9a3412'],
      ];
      foreach($stack as $s):
      ?>
      <div style="background:<?= $s[3] ?>;border-radius:9px;padding:.9rem 1rem;display:flex;align-items:center;gap:10px;">
        <span style="font-size:1.3rem;"><?= $s[2] ?></span>
        <div>
          <div style="font-weight:700;font-size:.83rem;color:<?= $s[4] ?>;"><?= $s[0] ?></div>
          <div style="font-size:.72rem;color:<?= $s[4] ?>;opacity:.75;"><?= $s[1] ?></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<?= $this->endSection() ?>
