<?= $this->extend('layout/admin') ?>
<?= $this->section('admin_content') ?>
<?php $artikel = $artikel ?? $data; ?>

<div style="max-width:780px;">
  <div style="display:flex;align-items:center;gap:.9rem;margin-bottom:1.5rem;">
    <a href="<?= base_url('admin/artikel') ?>" class="btn-sec"><i class="fa-solid fa-arrow-left"></i></a>
    <div>
      <h1 style="font-size:1.2rem;font-weight:700;color:#111827;margin:0;"><?= esc($title??'Edit Artikel') ?></h1>
      <p style="font-size:.78rem;color:#9CA3AF;margin:.1rem 0 0;">Perbarui konten, kategori, atau gambar sampul.</p>
    </div>
  </div>

  <?php if(!empty($errors)): ?>
    <div class="adm-alert-err"><ul class="mb-0 ps-3"><?php foreach($errors as $e): ?><li><?= esc($e) ?></li><?php endforeach; ?></ul></div>
  <?php endif; ?>

  <div class="adm-card" style="padding:1.75rem;">
    <form action="<?= base_url('admin/artikel/edit/'.$artikel['id']) ?>" method="post" enctype="multipart/form-data">
      <?= csrf_field() ?>

      <div style="margin-bottom:1.25rem;">
        <label class="adm-label">Judul Artikel <span style="color:#DC2626;">*</span></label>
        <input type="text" name="judul" class="adm-input" value="<?= old('judul',esc($artikel['judul'])) ?>" required>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;margin-bottom:1.25rem;">
        <div>
          <label class="adm-label">Kategori <span style="color:#DC2626;">*</span></label>
          <select name="id_kategori" class="adm-input" required>
            <?php foreach($kategori as $k): ?>
              <option value="<?= $k['id_kategori'] ?>" <?= old('id_kategori',$artikel['id_kategori'])==$k['id_kategori']?'selected':'' ?>><?= esc($k['nama_kategori']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label class="adm-label">Status Publikasi</label>
          <select name="status" class="adm-input">
            <option value="1" <?= old('status',$artikel['status']??1)==1?'selected':'' ?>>Publish (Aktif)</option>
            <option value="0" <?= old('status',$artikel['status']??1)==0?'selected':'' ?>>Draft</option>
          </select>
        </div>
      </div>

      <div style="margin-bottom:1.25rem;">
        <label class="adm-label">Isi Artikel <span style="color:#DC2626;">*</span></label>
        <textarea name="isi" class="adm-input" required><?= old('isi',esc($artikel['isi'])) ?></textarea>
      </div>

      <div style="margin-bottom:1.75rem;">
        <label class="adm-label">Gambar Sampul</label>
        <div style="display:grid;grid-template-columns:<?= !empty($artikel['gambar'])?'1fr 1fr':'1fr' ?>;gap:1rem;align-items:center;">
          <?php if(!empty($artikel['gambar'])): ?>
          <div style="background:#F3F4F6;border-radius:10px;overflow:hidden;border:1px solid #E5E7EB;">
            <img src="<?= base_url('gambar/'.$artikel['gambar']) ?>" style="width:100%;height:130px;object-fit:cover;display:block;">
            <div style="text-align:center;padding:.4rem;font-size:.72rem;color:#6B7280;">Gambar Saat Ini</div>
          </div>
          <?php endif; ?>
          <label style="display:flex;flex-direction:column;align-items:center;gap:.6rem;padding:1.5rem;border:2px dashed #E5E7EB;border-radius:10px;cursor:pointer;background:#fafafa;transition:all .2s;">
            <span style="font-size:1.5rem;">🔄</span>
            <span style="font-size:.78rem;color:#6B7280;text-align:center;">Ganti Gambar <span style="color:#9CA3AF;display:block;font-size:.68rem;">Kosongkan = tidak berubah</span></span>
            <input type="file" name="gambar" accept="image/jpeg,image/png,image/webp" style="display:none;" onchange="document.getElementById('fnameEdit').textContent=this.files[0]?'✅ '+this.files[0].name:'';">
          </label>
        </div>
        <span id="fnameEdit" style="display:block;margin-top:.4rem;font-size:.78rem;color:#059669;"></span>
      </div>

      <div style="display:flex;justify-content:flex-end;gap:.75rem;padding-top:1.25rem;border-top:1px solid #F3F4F6;">
        <a href="<?= base_url('admin/artikel') ?>" class="btn-sec">Batal</a>
        <button type="submit" class="btn-em"><i class="fa-solid fa-arrows-rotate"></i> Perbarui Artikel</button>
      </div>
    </form>
  </div>
</div>

<?= $this->endSection() ?>
