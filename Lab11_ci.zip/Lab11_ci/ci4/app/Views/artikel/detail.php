<?= $this->extend('layout/main') ?>
<?= $this->section('content') ?>
<style>
  .art-read{max-width:720px;margin:0 auto;}
  .art-read .cat-tag{display:inline-block;padding:3px 11px;background:#ecfdf5;color:#065f46;border-radius:99px;font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.5px;margin-bottom:1rem;}
  .art-read h1{font-size:clamp(1.7rem,4vw,2.4rem);font-weight:800;color:#111827;letter-spacing:-.7px;line-height:1.25;margin-bottom:1.25rem;}
  .art-meta-bar{display:flex;align-items:center;gap:1rem;padding:1rem 0;border-top:1px solid #F3F4F6;border-bottom:1px solid #F3F4F6;margin-bottom:2rem;}
  .art-avatar{width:38px;height:38px;background:linear-gradient(135deg,#059669,#34d399);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font-size:.85rem;font-weight:700;}
  .art-author-name{font-size:.88rem;font-weight:600;color:#111827;}
  .art-author-date{font-size:.75rem;color:#9CA3AF;}
  .art-cover{border-radius:12px;overflow:hidden;margin-bottom:2rem;border:1px solid #F3F4F6;}
  .art-cover img{width:100%;max-height:420px;object-fit:cover;display:block;}
  .art-body{font-size:1.05rem;line-height:1.9;color:#374151;white-space:pre-line;}
  .art-share{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:.75rem;padding:1rem 0;border-top:1px solid #F3F4F6;border-bottom:1px solid #F3F4F6;margin-top:2.5rem;}
  .art-share-label{font-size:.82rem;font-weight:600;color:#6B7280;}
  .share-icons{display:flex;gap:7px;}
  .share-btn{width:36px;height:36px;border-radius:8px;background:#F3F4F6;display:flex;align-items:center;justify-content:center;color:#6B7280;text-decoration:none;font-size:.85rem;transition:all .2s;}
  .share-btn:hover{background:#059669;color:#fff;}
  .btn-back-art{display:inline-flex;align-items:center;gap:7px;padding:8px 18px;background:#fff;border:1.5px solid #E5E7EB;border-radius:99px;color:#374151;text-decoration:none;font-size:.83rem;font-weight:600;margin-top:1.75rem;transition:all .2s;}
  .btn-back-art:hover{background:#059669;color:#fff;border-color:#059669;}
  nav.bc{margin-bottom:1.5rem;}
  nav.bc ol{list-style:none;display:flex;gap:.5rem;flex-wrap:wrap;font-size:.78rem;padding:0;}
  nav.bc li{color:#9CA3AF;}
  nav.bc li a{color:#9CA3AF;text-decoration:none;}
  nav.bc li a:hover{color:#059669;}
  nav.bc li+li::before{content:'›';margin-right:.5rem;}
</style>

<div class="art-read">
  <nav class="bc"><ol>
    <li><a href="<?= base_url('/') ?>">Beranda</a></li>
    <li><a href="<?= base_url('artikel') ?>">Artikel</a></li>
    <li>Detail</li>
  </ol></nav>

  <span class="cat-tag"><?= esc($artikel['nama_kategori']??'Umum') ?></span>
  <h1><?= esc($artikel['judul']) ?></h1>

  <div class="art-meta-bar">
    <div class="art-avatar">R</div>
    <div>
      <div class="art-author-name">Redaksi PressHub</div>
      <div class="art-author-date"><?= date('d F Y') ?> · Baca 3 menit</div>
    </div>
  </div>

  <?php if(!empty($artikel['gambar'])): ?>
  <div class="art-cover">
    <img src="<?= base_url('gambar/'.$artikel['gambar']) ?>" alt="<?= esc($artikel['judul']) ?>">
  </div>
  <?php endif; ?>

  <div class="art-body"><?= esc($artikel['isi']) ?></div>

  <div class="art-share">
    <span class="art-share-label">Bagikan:</span>
    <div class="share-icons">
      <a href="#" class="share-btn" title="Facebook"><i class="fa-brands fa-facebook-f"></i></a>
      <a href="#" class="share-btn" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
      <a href="#" class="share-btn" title="X/Twitter"><i class="fa-brands fa-x-twitter"></i></a>
      <a href="#" class="share-btn" title="Salin" onclick="navigator.clipboard.writeText(location.href);return false;"><i class="fa-solid fa-link"></i></a>
    </div>
  </div>

  <a href="<?= base_url('artikel') ?>" class="btn-back-art">← Kembali ke Artikel</a>
</div>

<?= $this->endSection() ?>
