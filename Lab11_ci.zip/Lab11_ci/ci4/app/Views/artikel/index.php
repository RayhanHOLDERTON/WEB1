<?= $this->extend('layout/main') ?>
<?= $this->section('content') ?>

<style>
  /* ── PUBLIC ARTIKEL — List style (beda dari original card grid) ── */
  .pub-head{margin-bottom:2rem;padding-bottom:1.25rem;border-bottom:2px solid #E5E7EB;}
  .pub-eyebrow{font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;color:#059669;margin-bottom:.4rem;}
  .pub-h1{font-size:2rem;font-weight:800;color:#111827;letter-spacing:-.5px;}

  /* Filter */
  .pub-filter{display:flex;flex-wrap:wrap;gap:.6rem;margin-bottom:1.75rem;}
  .pub-filter input,.pub-filter select{padding:8px 12px;border:1.5px solid #E5E7EB;border-radius:8px;font-size:.83rem;font-family:inherit;color:#374151;background:#fff;outline:none;transition:border .2s;}
  .pub-filter input:focus,.pub-filter select:focus{border-color:#059669;}
  .pub-filter input{min-width:200px;}
  .pub-filter-btn{padding:8px 18px;background:#059669;color:#fff;border:none;border-radius:8px;font-size:.83rem;font-weight:600;cursor:pointer;font-family:inherit;transition:background .2s;}
  .pub-filter-btn:hover{background:#047857;}
  .pub-filter-reset{padding:8px 14px;background:transparent;color:#6B7280;border:1.5px solid #E5E7EB;border-radius:8px;font-size:.83rem;font-weight:500;cursor:pointer;font-family:inherit;text-decoration:none;display:inline-flex;align-items:center;transition:all .2s;}
  .pub-filter-reset:hover{border-color:#9CA3AF;color:#374151;}

  /* FEATURED article — horizontal split */
  .art-featured{display:grid;grid-template-columns:1fr 1.1fr;gap:0;background:#fff;border:1px solid #E5E7EB;border-radius:14px;overflow:hidden;margin-bottom:2rem;box-shadow:0 2px 12px rgba(0,0,0,.04);}
  .art-featured-img{height:100%;min-height:260px;overflow:hidden;background:#F3F4F6;}
  .art-featured-img img{width:100%;height:100%;object-fit:cover;transition:transform .6s;}
  .art-featured:hover .art-featured-img img{transform:scale(1.04);}
  .art-featured-img .no-img{width:100%;height:100%;min-height:260px;display:flex;align-items:center;justify-content:center;font-size:2.5rem;color:#D1D5DB;}
  .art-featured-body{padding:2rem 1.75rem;display:flex;flex-direction:column;justify-content:center;}

  /* GRID list — 2 col */
  .art-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:1rem;}
  .art-item{background:#fff;border:1px solid #E5E7EB;border-radius:12px;overflow:hidden;display:flex;flex-direction:column;transition:box-shadow .25s,transform .25s;}
  .art-item:hover{box-shadow:0 8px 24px rgba(0,0,0,.07);transform:translateY(-3px);}
  .art-item-img{height:170px;overflow:hidden;background:#F3F4F6;flex-shrink:0;}
  .art-item-img img{width:100%;height:100%;object-fit:cover;transition:transform .5s;}
  .art-item:hover .art-item-img img{transform:scale(1.06);}
  .art-item-img .no-img{width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:1.5rem;color:#D1D5DB;}
  .art-item-body{padding:1.1rem 1.25rem 1.25rem;display:flex;flex-direction:column;flex:1;}

  /* Shared */
  .cat-tag{display:inline-block;padding:3px 9px;background:#ecfdf5;color:#065f46;border-radius:99px;font-size:.68rem;font-weight:700;text-transform:uppercase;letter-spacing:.5px;margin-bottom:.65rem;}
  .art-title{color:#111827;font-weight:700;text-decoration:none;line-height:1.4;transition:color .2s;}
  .art-title:hover{color:#059669;}
  .art-excerpt{font-size:.83rem;color:#6B7280;line-height:1.65;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;margin-bottom:.9rem;flex:1;}
  .art-meta{font-size:.72rem;color:#9CA3AF;display:flex;align-items:center;justify-content:space-between;margin-top:auto;padding-top:.7rem;border-top:1px solid #F3F4F6;}
  .read-link{font-size:.78rem;font-weight:600;color:#059669;text-decoration:none;transition:gap .2s;display:inline-flex;align-items:center;gap:5px;}
  .read-link:hover{color:#047857;gap:9px;}

  .empty-box{text-align:center;padding:4rem 1rem;border:2px dashed #E5E7EB;border-radius:14px;}
  .clamp3{display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden;}
</style>

<!-- Header -->
<div class="pub-head">
  <p class="pub-eyebrow">PressHub</p>
  <h1 class="pub-h1">Berita &amp; Artikel Terkini</h1>
</div>

<!-- Filter -->
<form method="get" action="<?= base_url('artikel') ?>">
  <div class="pub-filter">
    <input type="text" name="q" value="<?= esc($q ?? '') ?>" placeholder="🔍 Cari artikel...">
    <select name="kategori_id">
      <option value="">Semua Kategori</option>
      <?php foreach($kategori as $k): ?>
        <option value="<?= $k['id_kategori'] ?>" <?= ($kategori_id??'')==$k['id_kategori']?'selected':'' ?>><?= esc($k['nama_kategori']) ?></option>
      <?php endforeach; ?>
    </select>
    <select name="sort">
      <option value="id_desc"   <?= ($sort??'')==='id_desc'   ?'selected':'' ?>>Terbaru</option>
      <option value="id_asc"    <?= ($sort??'')==='id_asc'    ?'selected':'' ?>>Terlama</option>
      <option value="judul_asc" <?= ($sort??'')==='judul_asc' ?'selected':'' ?>>Judul A–Z</option>
      <option value="judul_desc"<?= ($sort??'')==='judul_desc'?'selected':'' ?>>Judul Z–A</option>
    </select>
    <button type="submit" class="pub-filter-btn">Filter</button>
    <?php if(!empty($q)||!empty($kategori_id)||(!empty($sort)&&$sort!=='id_desc')): ?>
      <a href="<?= base_url('artikel') ?>" class="pub-filter-reset">Reset</a>
    <?php endif; ?>
  </div>
</form>

<?php if(!empty($artikel)): ?>
  <?php $first = array_shift($artikel); ?>

  <!-- Featured -->
  <div class="art-featured">
    <div class="art-featured-img">
      <?php if(!empty($first['gambar'])): ?>
        <img src="<?= base_url('gambar/'.$first['gambar']) ?>" alt="<?= esc($first['judul']) ?>">
      <?php else: ?><div class="no-img">📄</div><?php endif; ?>
    </div>
    <div class="art-featured-body">
      <span class="cat-tag"><?= esc($first['nama_kategori']??'Umum') ?></span>
      <h2 style="font-size:1.45rem;font-weight:800;color:#111827;letter-spacing:-.4px;line-height:1.3;margin-bottom:1rem;">
        <a href="<?= base_url('artikel/'.($first['slug']??$first['id'])) ?>" class="art-title" style="font-size:inherit;"><?= esc($first['judul']) ?></a>
      </h2>
      <p class="clamp3" style="font-size:.9rem;color:#6B7280;line-height:1.75;margin-bottom:1.25rem;"><?= esc(strip_tags($first['isi'])) ?></p>
      <div style="display:flex;align-items:center;justify-content:space-between;">
        <span style="font-size:.75rem;color:#9CA3AF;"><?= date('d M Y',strtotime($first['created_at']??'now')) ?></span>
        <a href="<?= base_url('artikel/'.($first['slug']??$first['id'])) ?>" class="read-link">Baca Selengkapnya →</a>
      </div>
    </div>
  </div>

  <!-- Grid -->
  <?php if(!empty($artikel)): ?>
  <div class="art-grid">
    <?php foreach($artikel as $row): ?>
    <div class="art-item">
      <div class="art-item-img">
        <?php if(!empty($row['gambar'])): ?>
          <img src="<?= base_url('gambar/'.$row['gambar']) ?>" alt="<?= esc($row['judul']) ?>">
        <?php else: ?><div class="no-img">📄</div><?php endif; ?>
      </div>
      <div class="art-item-body">
        <span class="cat-tag"><?= esc($row['nama_kategori']??'Umum') ?></span>
        <a href="<?= base_url('artikel/'.($row['slug']??$row['id'])) ?>" class="art-title" style="font-size:.95rem;display:block;margin-bottom:.6rem;"><?= esc($row['judul']) ?></a>
        <p class="art-excerpt"><?= esc(strip_tags($row['isi'])) ?></p>
        <div class="art-meta">
          <span><?= date('d M Y',strtotime($row['created_at']??'now')) ?></span>
          <a href="<?= base_url('artikel/'.($row['slug']??$row['id'])) ?>" class="read-link">Baca →</a>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

<?php else: ?>
  <div class="empty-box">
    <div style="font-size:2rem;margin-bottom:.75rem;">📭</div>
    <h4 style="font-weight:700;color:#111827;margin-bottom:.4rem;">Tidak Ada Artikel</h4>
    <p style="color:#6B7280;font-size:.88rem;">Belum ada artikel yang dipublikasikan.</p>
  </div>
<?php endif; ?>

<?= $this->endSection() ?>
