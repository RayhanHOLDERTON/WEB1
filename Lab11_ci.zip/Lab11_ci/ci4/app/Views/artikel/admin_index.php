<?= $this->extend('layout/admin') ?>
<?= $this->section('admin_content') ?>

<div class="adm-page-head">
  <h1>Kelola Artikel</h1>
  <p class="sub">Tambah, ubah, dan hapus data artikel portal.</p>
</div>

<!-- Filter -->
<div class="filter-bar">
  <input type="text" id="searchBox" placeholder="🔍 Cari judul artikel...">
  <select id="categoryFilter">
    <option value="">Semua Kategori</option>
    <?php foreach($kategori as $k): ?>
      <option value="<?= $k['id_kategori'] ?>"><?= esc($k['nama_kategori']) ?></option>
    <?php endforeach; ?>
  </select>
  <select id="sortFilter">
    <option value="id_desc">Terbaru</option>
    <option value="id_asc">Terlama</option>
    <option value="judul_asc">Judul A–Z</option>
    <option value="judul_desc">Judul Z–A</option>
  </select>
  <button id="btnFilter" class="btn-em"><i class="fa-solid fa-filter"></i> Filter</button>
</div>

<!-- Table Card -->
<div class="adm-card">
  <div class="adm-card-head">
    <h6>Daftar Artikel</h6>
    <a href="<?= base_url('admin/artikel/add') ?>" class="btn-em">
      <i class="fa-solid fa-plus"></i> Tambah
    </a>
  </div>
  <div style="overflow-x:auto;">
    <table class="adm-table" id="artikelTable">
      <thead>
        <tr>
          <th style="width:60px;">Gambar</th>
          <th>Judul &amp; Konten</th>
          <th style="width:130px;">Kategori</th>
          <th style="width:95px;">Status</th>
          <th style="width:130px;text-align:right;">Aksi</th>
        </tr>
      </thead>
      <tbody id="tableBody">
        <tr><td colspan="5" style="text-align:center;padding:40px;color:#9CA3AF;">Memuat data…</td></tr>
      </tbody>
    </table>
  </div>
</div>

<div class="pager" id="paginationBox"></div>

<script>
$(function(){
  function fetchData(url){
    $('#tableBody').html('<tr><td colspan="5" style="text-align:center;padding:40px;color:#9CA3AF;">Memuat data…</td></tr>');
    $.ajax({
      url,type:'GET',dataType:'json',
      headers:{'X-Requested-With':'XMLHttpRequest'},
      success(res){
        let html='';
        if(res.artikel&&res.artikel.length>0){
          $.each(res.artikel,function(i,row){
            const img=row.gambar
              ?'<?= base_url('gambar/') ?>'+row.gambar
              :'<?= base_url('gambar/default.jpg') ?>';
            const kat=row.nama_kategori
              ?`<span style="background:#ecfdf5;color:#065f46;padding:2px 8px;border-radius:99px;font-size:.68rem;font-weight:700;">${row.nama_kategori}</span>`
              :'<span style="color:#9CA3AF;font-size:.75rem;">—</span>';
            const status=row.status==1
              ?'<span class="bpub">Aktif</span>'
              :'<span class="bdraft">Draft</span>';
            const exc=row.isi?(row.isi.replace(/<[^>]*>/gm,'').substring(0,70)+'…'):'';
            html+=`<tr>
              <td><img src="${img}" style="width:44px;height:44px;object-fit:cover;border-radius:7px;border:1px solid #E5E7EB;"></td>
              <td>
                <div style="font-weight:600;color:#111827;font-size:.83rem;margin-bottom:3px;">${row.judul}</div>
                <div style="font-size:.72rem;color:#9CA3AF;">${exc}</div>
              </td>
              <td>${kat}</td>
              <td>${status}</td>
              <td style="text-align:right;">
                <a href="<?= base_url('admin/artikel/edit/') ?>${row.id}" class="btn-ed">Edit</a>
                <a href="<?= base_url('admin/artikel/delete/') ?>${row.id}" class="btn-dl"
                   onclick="return confirm('Hapus artikel ini?')">Hapus</a>
              </td>
            </tr>`;
          });
        }else{
          html='<tr><td colspan="5" style="text-align:center;padding:48px;color:#9CA3AF;">Tidak ada artikel.</td></tr>';
        }
        $('#tableBody').html(html);
        let pag='';
        if(res.pager_links){$.each(res.pager_links,function(i,l){
          const cls=l.active?'active':'';
          const href=l.url&&l.url!=='#'?l.url:'javascript:void(0)';
          pag+=`<a class="${cls}" href="${href}">${l.title}</a>`;
        });}
        $('#paginationBox').html(pag);
      },
      error(){$('#tableBody').html('<tr><td colspan="5" style="text-align:center;padding:40px;color:#DC2626;">Gagal memuat data.</td></tr>');}
    });
  }
  function buildUrl(base){
    return `${base}?q=${encodeURIComponent($('#searchBox').val())}&kategori_id=${$('#categoryFilter').val()}&sort=${$('#sortFilter').val()}`;
  }
  $(document).on('click','.pager a',function(e){
    e.preventDefault();
    const href=$(this).attr('href');
    if(href&&href!=='javascript:void(0)'){
      try{const page=new URL(href).searchParams.get('page')||1;fetchData(buildUrl('<?= base_url('admin/artikel') ?>')+'&page='+page);}
      catch(err){fetchData(href);}
    }
  });
  $('#btnFilter').on('click',e=>{e.preventDefault();fetchData(buildUrl('<?= base_url('admin/artikel') ?>'));});
  $('#categoryFilter,#sortFilter').on('change',()=>fetchData(buildUrl('<?= base_url('admin/artikel') ?>')));
  $('#searchBox').on('keypress',e=>{if(e.key==='Enter')fetchData(buildUrl('<?= base_url('admin/artikel') ?>'));});
  fetchData('<?= base_url('admin/artikel') ?>');
});
</script>

<?= $this->endSection() ?>
